package com.studentgig;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StudentGigApplication {

    public static void main(String[] args) {
        SpringApplication.run(StudentGigApplication.class, args);
    }
}
