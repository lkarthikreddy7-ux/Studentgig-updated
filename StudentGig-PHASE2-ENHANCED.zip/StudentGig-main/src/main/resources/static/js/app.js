const API_BASE = '/api';

const CATEGORIES = [
    'Coding', 'Web Development', 'Graphic Design', 'Video Editing',
    'Writing', 'Tutoring', 'Photography', 'Presentation',
    'Social Media', 'Data Entry', 'Other'
];

const YEAR_STATUS_OPTIONS = [
    '1st Year', '2nd Year', '3rd Year', '4th Year', 'Graduate',
    'Working Professional', 'Freelancer', 'Business Owner', 'Homemaker', 'Other'
];

function yearStatusOptionsHtml(selected = '') {
    return YEAR_STATUS_OPTIONS.map(opt =>
        `<option value="${opt}" ${opt === selected ? 'selected' : ''}>${opt}</option>`
    ).join('');
}

function formatUserProfile(user) {
    const parts = [user.college, user.department, user.year].filter(Boolean);
    return parts.join(' · ') || 'Member';
}

let currentUser = null;

async function apiCall(endpoint, options = {}) {
    const config = {
        credentials: 'include',
        headers: { 'Content-Type': 'application/json', ...options.headers },
        ...options
    };
    if (config.body && typeof config.body === 'object') {
        config.body = JSON.stringify(config.body);
    }
    const response = await fetch(API_BASE + endpoint, config);
    const data = await response.json().catch(() => ({}));
    if (!response.ok) {
        throw new Error(data.error || 'Something went wrong');
    }
    return data;
}

function showToast(message, type = 'success') {
    let container = document.querySelector('.toast-container');
    if (!container) {
        container = document.createElement('div');
        container.className = 'toast-container';
        document.body.appendChild(container);
    }
    const toast = document.createElement('div');
    toast.className = `toast toast-${type}`;
    toast.textContent = message;
    container.appendChild(toast);
    setTimeout(() => toast.remove(), 4000);
}

function formatDate(dateStr) {
    if (!dateStr) return 'N/A';
    const d = new Date(dateStr);
    return d.toLocaleDateString('en-IN', { year: 'numeric', month: 'short', day: 'numeric' });
}

function formatCurrency(amount) {
    return '₹' + Number(amount).toLocaleString('en-IN');
}

function renderStars(rating) {
    const full = Math.floor(rating);
    const half = rating % 1 >= 0.5 ? 1 : 0;
    let stars = '';
    for (let i = 0; i < full; i++) stars += '★';
    if (half) stars += '½';
    for (let i = full + half; i < 5; i++) stars += '☆';
    return stars;
}

function statusBadge(status) {
    const cls = (status || '').toLowerCase().replace(' ', '_');
    return `<span class="badge badge-${cls}">${(status || '').replace('_', ' ')}</span>`;
}

function skillsHtml(skills) {
    if (!skills || !skills.length) return '';
    return `<div class="skills-tags">${skills.map(s => `<span class="skill-tag">${s}</span>`).join('')}</div>`;
}

function getInitials(name) {
    if (!name) return '?';
    return name.split(' ').map(w => w[0]).join('').toUpperCase().slice(0, 2);
}

async function checkAuth() {
    try {
        const data = await apiCall('/auth/current');
        if (data.loggedIn) {
            currentUser = data;
            return data;
        }
        currentUser = null;
        return null;
    } catch {
        currentUser = null;
        return null;
    }
}

function renderNavbar(activePage = '') {
    const nav = document.getElementById('navbar');
    if (!nav) return;

    const isLoggedIn = currentUser && currentUser.loggedIn !== false;

    nav.innerHTML = `
        <div class="nav-container">
            <a href="/index.html" class="logo">StudentGig</a>
            <button class="hamburger" onclick="toggleMenu()">☰</button>
            <ul class="nav-links" id="navLinks">
                <li><a href="/index.html" class="${activePage === 'home' ? 'active' : ''}">Home</a></li>
                <li><a href="/jobs.html" class="${activePage === 'jobs' ? 'active' : ''}">Browse Jobs</a></li>
                ${isLoggedIn ? `
                    <li><a href="/dashboard.html" class="${activePage === 'dashboard' ? 'active' : ''}">Dashboard</a></li>
                    <li><a href="/active-jobs.html" class="${activePage === 'active' ? 'active' : ''}">Active Jobs</a></li>
                    <li><a href="/my-jobs.html" class="${activePage === 'my-jobs' ? 'active' : ''}">My Jobs</a></li>
                    <li><a href="/portfolio.html" class="${activePage === 'portfolio' ? 'active' : ''}">Portfolio</a></li>
                    ${currentUser.email === 'admin@studentgig.com' ? '<li><a href="/admin.html">Admin</a></li>' : ''}
                ` : ''}
            </ul>
            <div class="nav-actions">
                ${isLoggedIn ? `
                    <div style="position:relative">
                        <button class="notification-btn" onclick="toggleNotifications(event)">🔔<span class="notification-badge" id="notifBadge" style="display:none">0</span></button>
                        <div class="notification-dropdown" id="notifDropdown"></div>
                    </div>
                    <a href="/profile.html" class="btn btn-sm btn-outline">${currentUser.name}</a>
                    <button class="btn btn-sm btn-primary" onclick="logout()">Logout</button>
                ` : `
                    <a href="/login.html" class="btn btn-sm btn-outline">Login</a>
                    <a href="/register.html" class="btn btn-sm btn-primary">Register</a>
                `}
            </div>
        </div>`;

    if (isLoggedIn) loadNotificationCount();
}

function toggleMenu() {
    document.getElementById('navLinks')?.classList.toggle('show');
}

async function logout() {
    try {
        await apiCall('/auth/logout', { method: 'POST' });
        currentUser = null;
        showToast('Logged out successfully');
        window.location.href = '/index.html';
    } catch (e) {
        showToast(e.message, 'error');
    }
}

async function loadNotificationCount() {
    try {
        const data = await apiCall('/notifications/unread-count');
        const badge = document.getElementById('notifBadge');
        if (badge && data.count > 0) {
            badge.textContent = data.count;
            badge.style.display = 'block';
        }
    } catch {}
}

async function toggleNotifications(e) {
    e.stopPropagation();
    const dropdown = document.getElementById('notifDropdown');
    if (!dropdown) return;

    if (dropdown.classList.contains('show')) {
        dropdown.classList.remove('show');
        return;
    }

    try {
        const notifications = await apiCall('/notifications');
        if (notifications.length === 0) {
            dropdown.innerHTML = '<div class="notification-item">No notifications</div>';
        } else {
            dropdown.innerHTML = notifications.map(n => `
                <div class="notification-item ${n.read ? '' : 'unread'}" onclick="markNotifRead(${n.id})">
                    ${n.message}
                    <div class="notification-time">${formatDate(n.createdAt)}</div>
                </div>
            `).join('');
        }
        dropdown.classList.add('show');
    } catch {
        dropdown.innerHTML = '<div class="notification-item">Failed to load</div>';
        dropdown.classList.add('show');
    }
}

async function markNotifRead(id) {
    try {
        await apiCall(`/notifications/${id}/read`, { method: 'PUT' });
        loadNotificationCount();
    } catch {}
}

document.addEventListener('click', () => {
    document.getElementById('notifDropdown')?.classList.remove('show');
});

function renderFooter() {
    const footer = document.getElementById('footer');
    if (!footer) return;
    footer.innerHTML = `
        <div class="footer-grid">
            <div>
                <h4>StudentGig</h4>
                <p>A freelancing marketplace for students, professionals, and everyone with skills to offer.</p>
            </div>
            <div>
                <h4>Platform</h4>
                <ul>
                    <li><a href="/jobs.html">Browse Jobs</a></li>
                    <li><a href="/post-job.html">Post a Job</a></li>
                    <li><a href="/dashboard.html">Dashboard</a></li>
                </ul>
            </div>
            <div>
                <h4>Categories</h4>
                <ul>
                    <li><a href="/jobs.html?category=Web Development">Web Development</a></li>
                    <li><a href="/jobs.html?category=Graphic Design">Graphic Design</a></li>
                    <li><a href="/jobs.html?category=Coding">Coding</a></li>
                </ul>
            </div>
            <div>
                <h4>Account</h4>
                <ul>
                    <li><a href="/login.html">Login</a></li>
                    <li><a href="/register.html">Register</a></li>
                    <li><a href="/profile.html">Profile</a></li>
                </ul>
            </div>
        </div>
        <div class="footer-bottom">
            <p>&copy; 2026 StudentGig. All rights reserved.</p>
        </div>`;
}

function requireAuth() {
    if (!currentUser || currentUser.loggedIn === false) {
        showToast('Please login first', 'error');
        setTimeout(() => window.location.href = '/login.html', 1500);
        return false;
    }
    return true;
}

function jobCardHtml(job) {
    return `
        <div class="job-card">
            <div style="display:flex;justify-content:space-between;align-items:start">
                <h3>${job.title}</h3>
                ${statusBadge(job.status)}
            </div>
            <p class="description">${job.description}</p>
            ${skillsHtml(job.skillsRequired)}
            <div class="job-meta">
                <span>📁 ${job.category}</span>
                <span>📅 ${job.deadline}</span>
                <span>👤 ${job.clientName || 'Client'}</span>
                ${job.clientRating ? `<span>⭐ ${job.clientRating}</span>` : ''}
            </div>
            <div style="display:flex;justify-content:space-between;align-items:center;margin-top:auto">
                <span class="job-budget">${formatCurrency(job.budget)}</span>
                <a href="/job-details.html?id=${job.id}" class="btn btn-sm btn-primary">View Details</a>
            </div>
        </div>`;
}

async function initPage(activePage) {
    await checkAuth();
    renderNavbar(activePage);
    renderFooter();
}
