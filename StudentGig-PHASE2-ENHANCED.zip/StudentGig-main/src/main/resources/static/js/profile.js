document.addEventListener('DOMContentLoaded', async () => {
    await initPage('profile');
    if (!requireAuth()) return;

    await loadProfile();

    document.getElementById('profileForm').addEventListener('submit', async (e) => {
        e.preventDefault();
        const skills = document.getElementById('editSkills').value
            .split(',').map(s => s.trim()).filter(Boolean);
        const updates = {
            name: document.getElementById('editName').value,
            college: document.getElementById('editCollege').value,
            department: document.getElementById('editDepartment').value,
            year: document.getElementById('editYear').value,
            skills
        };
        try {
            const updated = await apiCall(`/users/${currentUser.id}`, { method: 'PUT', body: updates });
            currentUser = { ...currentUser, ...updated };
            showToast('Profile updated successfully!');
            await loadProfile();
        } catch (err) {
            showToast(err.message, 'error');
        }
    });
});

async function loadProfile() {
    try {
        const [user, stats, reviews] = await Promise.all([
            apiCall(`/users/${currentUser.id}`),
            apiCall(`/users/${currentUser.id}/stats`),
            apiCall(`/users/${currentUser.id}/reviews`)
        ]);

        document.getElementById('profileAvatar').textContent = getInitials(user.name);
        document.getElementById('profileName').textContent = user.name;
        document.getElementById('profileCollege').textContent = formatUserProfile(user);
        document.getElementById('profileRating').innerHTML = `${renderStars(user.rating)} ${user.rating} (${user.totalReviews} reviews)`;
        document.getElementById('profileSkills').innerHTML = skillsHtml(user.skills);
        const completion = await apiCall(`/users/${currentUser.id}/profile-completion`);
        document.getElementById('profileCompletionPercent').textContent = completion.percentage + '%';
        document.getElementById('profileCompletionText').textContent = completion.missing.length ? 'Complete: ' + completion.missing.join(', ') : 'Profile is complete!';
        document.getElementById('profileCompletionBar').style.width = completion.percentage + '%';

        document.getElementById('editName').value = user.name;
        document.getElementById('editCollege').value = user.college || '';
        document.getElementById('editDepartment').value = user.department || '';
        document.getElementById('editYear').innerHTML =
            '<option value="">Select your status</option>' + yearStatusOptionsHtml(user.year || '');
        document.getElementById('editSkills').value = (user.skills || []).join(', ');

        document.getElementById('statsGrid').innerHTML = `
            <div class="stat-card"><div class="stat-value">${stats.jobsPosted}</div><div class="stat-label">Jobs Posted</div></div>
            <div class="stat-card"><div class="stat-value">${stats.jobsCompleted}</div><div class="stat-label">Jobs Completed</div></div>
            <div class="stat-card"><div class="stat-value">${stats.jobsWorkedOn}</div><div class="stat-label">Jobs Worked On</div></div>
            <div class="stat-card"><div class="stat-value">${stats.applications}</div><div class="stat-label">Applications</div></div>
            <div class="stat-card"><div class="stat-value">${stats.averageRating || 0}</div><div class="stat-label">Avg Rating</div></div>`;

        const reviewsEl = document.getElementById('reviewsList');
        if (reviews.length > 0) {
            reviewsEl.innerHTML = reviews.map(r => `
                <div class="review-card" style="margin-bottom:16px">
                    <div class="stars">${renderStars(r.rating)}</div>
                    <p>"${r.comment}"</p>
                    <p style="font-size:0.85rem;color:var(--text-light);margin-top:8px">
                        ${r.reviewerName || 'User'} · ${r.jobTitle || 'Job'} · ${formatDate(r.createdAt)}
                    </p>
                </div>
            `).join('');
        } else {
            reviewsEl.innerHTML = '<p style="color:var(--text-light)">No reviews yet</p>';
        }
    } catch (err) {
        showToast(err.message, 'error');
    }
}
