document.addEventListener('DOMContentLoaded', async () => {
    await initPage('dashboard');
    if (!requireAuth()) return;

    try {
        const stats = await apiCall(`/users/${currentUser.id}/stats`);
        document.getElementById('statJobsPosted').textContent = stats.jobsPosted;
        document.getElementById('statActiveJobs').textContent = stats.jobsPosted - stats.jobsCompleted;
        document.getElementById('statCompleted').textContent = stats.jobsCompleted + stats.jobsWorkedOn;
        document.getElementById('statApplications').textContent = stats.applications;
        document.getElementById('statRating').textContent = stats.averageRating || '0';

        document.getElementById('welcomeMsg').textContent = `Welcome back, ${currentUser.name}!`;

        const [jobs, activeJobs, proposals, completedJobs] = await Promise.all([
            apiCall('/jobs/recommended'),
            apiCall('/jobs/active'),
            apiCall('/proposals/my'),
            apiCall('/jobs/completed')
        ]);

        const recommended = document.getElementById('recommendedJobs');
        if (jobs.length > 0) {
            recommended.innerHTML = `<div class="card-grid">${jobs.slice(0, 3).map(jobCardHtml).join('')}</div>`;
            const matchInfo = jobs.slice(0, 3).map(job => {
                const percentage = Number(job.matchPercentage || 0);
                return `<div style="font-size:0.85rem;color:var(--text-light);margin-top:6px">🎯 Skill match: <strong>${percentage}%</strong> (${job.matchingSkills || 0}/${job.requiredSkills || 0} skills)</div>`;
            }).join('');
            recommended.insertAdjacentHTML('beforeend', `<div style="margin-top:12px">${matchInfo}</div>`);
        } else {
            recommended.innerHTML = '<p class="empty-state">No matching open jobs right now</p>';
        }

        const activeEl = document.getElementById('activeJobsSection');
        if (activeJobs.length > 0) {
            activeEl.innerHTML = activeJobs.slice(0, 3).map(j => `
                <div class="job-card" style="margin-bottom:12px">
                    <h3>${j.title}</h3>
                    <div class="job-meta">
                        ${statusBadge(j.status)}
                        <span class="job-budget">${formatCurrency(j.budget)}</span>
                    </div>
                    <a href="/job-details.html?id=${j.id}" class="btn btn-sm btn-outline" style="margin-top:8px">View</a>
                </div>
            `).join('');
        } else {
            activeEl.innerHTML = '<p style="color:var(--text-light)">No active jobs</p>';
        }

        const proposalsEl = document.getElementById('recentProposals');
        if (proposals.length > 0) {
            proposalsEl.innerHTML = proposals.slice(0, 5).map(p => `
                <div class="proposal-card" style="padding:16px">
                    <div style="display:flex;justify-content:space-between">
                        <strong>${p.jobTitle || 'Job'}</strong>
                        ${statusBadge(p.status)}
                    </div>
                    <p style="font-size:0.9rem;color:var(--text-light);margin-top:4px">${formatCurrency(p.proposedPrice)} · ${p.deliveryDays} days</p>
                </div>
            `).join('');
        } else {
            proposalsEl.innerHTML = '<p style="color:var(--text-light)">No proposals yet. <a href="/jobs.html">Browse jobs</a></p>';
        }

        const completedEl = document.getElementById('completedSection');
        if (completedJobs.length > 0) {
            completedEl.innerHTML = completedJobs.slice(0, 3).map(j => `
                <div class="job-card" style="margin-bottom:12px">
                    <h3>${j.title}</h3>
                    <div class="job-meta">
                        <span>✅ ${formatDate(j.completedAt)}</span>
                        <span class="job-budget">${formatCurrency(j.budget)}</span>
                    </div>
                </div>
            `).join('');
        } else {
            completedEl.innerHTML = '<p style="color:var(--text-light)">No completed jobs yet</p>';
        }
    } catch (err) {
        showToast(err.message, 'error');
    }
});
