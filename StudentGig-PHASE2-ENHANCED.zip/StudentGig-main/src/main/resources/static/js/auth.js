document.addEventListener('DOMContentLoaded', async () => {
    await initPage('');

    const loginForm = document.getElementById('loginForm');
    if (loginForm) {
        loginForm.addEventListener('submit', async (e) => {
            e.preventDefault();
            const email = document.getElementById('email').value;
            const password = document.getElementById('password').value;
            try {
                const user = await apiCall('/auth/login', {
                    method: 'POST',
                    body: { email, password }
                });
                currentUser = user;
                showToast('Login successful!');
                setTimeout(() => window.location.href = '/dashboard.html', 1000);
            } catch (err) {
                showToast(err.message, 'error');
            }
        });
    }

    const registerForm = document.getElementById('registerForm');
    if (registerForm) {
        registerForm.addEventListener('submit', async (e) => {
            e.preventDefault();
            const skills = document.getElementById('skills').value
                .split(',').map(s => s.trim()).filter(Boolean);
            const user = {
                name: document.getElementById('name').value,
                email: document.getElementById('email').value,
                password: document.getElementById('password').value,
                college: document.getElementById('college').value,
                department: document.getElementById('department').value,
                year: document.getElementById('year').value,
                skills
            };
            try {
                const result = await apiCall('/auth/register', {
                    method: 'POST',
                    body: user
                });
                currentUser = result;
                showToast('Registration successful!');
                setTimeout(() => window.location.href = '/dashboard.html', 1000);
            } catch (err) {
                showToast(err.message, 'error');
            }
        });
    }
});
