document.addEventListener('DOMContentLoaded', async () => {
    await initPage('jobs');

    const params = new URLSearchParams(window.location.search);
    const categoryParam = params.get('category') || '';
    const searchParam = params.get('search') || '';

    const searchInput = document.getElementById('searchInput');
    const categoryFilter = document.getElementById('categoryFilter');
    const sortFilter = document.getElementById('sortFilter');

    if (searchInput) searchInput.value = searchParam;
    if (categoryFilter) {
        CATEGORIES.forEach(cat => {
            const opt = document.createElement('option');
            opt.value = cat;
            opt.textContent = cat;
            if (cat === categoryParam) opt.selected = true;
            categoryFilter.appendChild(opt);
        });
    }

    await loadJobs();

    sortFilter?.addEventListener('change', loadJobs);
    document.getElementById('searchBtn')?.addEventListener('click', loadJobs);
    searchInput?.addEventListener('keypress', (e) => { if (e.key === 'Enter') loadJobs(); });
    categoryFilter?.addEventListener('change', loadJobs);
});

async function loadJobs() {
    const search = document.getElementById('searchInput')?.value || '';
    const category = document.getElementById('categoryFilter')?.value || '';
    const sort = document.getElementById('sortFilter')?.value || 'newest';
    let url = `/jobs?sort=${encodeURIComponent(sort)}&`;
    if (search) url += `search=${encodeURIComponent(search)}&`;
    if (category) url += `category=${encodeURIComponent(category)}&`;

    const container = document.getElementById('jobsContainer');
    try {
        const jobs = await apiCall(url);
        if (jobs.length === 0) {
            container.innerHTML = `<div class="empty-state"><div class="icon">📭</div><h3>No jobs found</h3><p>Try adjusting your search or check back later.</p></div>`;
            return;
        }
        container.innerHTML = `<div class="card-grid">${jobs.map(jobCardHtml).join('')}</div>`;
    } catch (err) {
        container.innerHTML = `<div class="empty-state"><p>${err.message}</p></div>`;
    }
}

// Job Details Page
async function loadJobDetails() {
    await initPage('jobs');
    const params = new URLSearchParams(window.location.search);
    const jobId = params.get('id');
    if (!jobId) { window.location.href = '/jobs.html'; return; }

    try {
        const job = await apiCall(`/jobs/${jobId}`);
        document.getElementById('jobDetail').innerHTML = `
            <div class="job-detail">
                <div style="display:flex;justify-content:space-between;align-items:start;flex-wrap:wrap;gap:12px">
                    <h1>${job.title}</h1>
                    ${statusBadge(job.status)}
                </div>
                <p style="margin:16px 0;color:var(--text-light)">${job.description}</p>
                ${skillsHtml(job.skillsRequired)}
                <div class="detail-row" style="margin-top:20px">
                    <div class="detail-item"><label>Category</label><span>${job.category}</span></div>
                    <div class="detail-item"><label>Budget</label><span>${formatCurrency(job.budget)}</span></div>
                    <div class="detail-item"><label>Deadline</label><span>${job.deadline}</span></div>
                    <div class="detail-item"><label>Client</label><span>${job.clientName || 'N/A'} ${job.clientRating ? '⭐ ' + job.clientRating : ''}</span></div>
                    <div class="detail-item"><label>Posted</label><span>${formatDate(job.createdAt)}</span></div>
                </div>
            </div>`;

        const actions = document.getElementById('jobActions');
        if (job.status === 'OPEN' && currentUser && job.clientId !== currentUser.id) {
            actions.innerHTML = `<button class="btn btn-primary" onclick="showProposalForm()">Apply Now</button>`;
        } else if (job.status === 'OPEN' && currentUser && job.clientId === currentUser.id) {
            actions.innerHTML = `
                <a href="/proposals.html?jobId=${job.id}" class="btn btn-primary">View Proposals</a>
                <a href="/my-jobs.html" class="btn btn-outline">Edit Job</a>`;
        } else if (job.status === 'IN_PROGRESS' && currentUser && job.freelancerId === currentUser.id) {
            actions.innerHTML = `<a href="/submit-work.html?jobId=${job.id}" class="btn btn-primary">Submit Work</a>`;
        } else if (job.status === 'SUBMITTED' && currentUser && job.clientId === currentUser.id) {
            actions.innerHTML = `<a href="/submit-work.html?jobId=${job.id}" class="btn btn-primary">Review Submission</a>`;
        } else if (job.status === 'COMPLETED') {
            actions.innerHTML = `<span class="badge badge-completed">Completed</span>`;
        }
    } catch (err) {
        showToast(err.message, 'error');
    }
}

function showProposalForm() {
    if (!requireAuth()) return;
    document.getElementById('proposalModal').style.display = 'flex';
}

async function submitProposal(e) {
    e.preventDefault();
    const params = new URLSearchParams(window.location.search);
    const jobId = params.get('id');
    const proposal = {
        proposedPrice: parseFloat(document.getElementById('proposedPrice').value),
        deliveryDays: parseInt(document.getElementById('deliveryDays').value),
        coverMessage: document.getElementById('coverMessage').value
    };
    try {
        const result = await apiCall(`/jobs/${jobId}/proposals`, { method: 'POST', body: proposal });
        showToast(result.message || 'Proposal submitted!');
        document.getElementById('proposalModal').style.display = 'none';
    } catch (err) {
        showToast(err.message, 'error');
    }
}

// Post Job
async function initPostJob() {
    await initPage('my-jobs');
    if (!requireAuth()) return;

    const categorySelect = document.getElementById('category');
    CATEGORIES.forEach(cat => {
        const opt = document.createElement('option');
        opt.value = cat;
        opt.textContent = cat;
        categorySelect.appendChild(opt);
    });

    const params = new URLSearchParams(window.location.search);
    const editId = params.get('edit');
    if (editId) {
        const job = await apiCall(`/jobs/${editId}`);
        document.getElementById('title').value = job.title;
        document.getElementById('description').value = job.description;
        document.getElementById('category').value = job.category;
        document.getElementById('skillsRequired').value = (job.skillsRequired || []).join(', ');
        document.getElementById('budget').value = job.budget;
        document.getElementById('deadline').value = job.deadline;
        document.getElementById('postJobForm').dataset.editId = editId;
        document.querySelector('.page-header h1').textContent = 'Edit Job';
    }

    document.getElementById('postJobForm').addEventListener('submit', async (e) => {
        e.preventDefault();
        const form = e.target;
        const job = {
            title: document.getElementById('title').value,
            description: document.getElementById('description').value,
            category: document.getElementById('category').value,
            skillsRequired: document.getElementById('skillsRequired').value.split(',').map(s => s.trim()).filter(Boolean),
            budget: parseFloat(document.getElementById('budget').value),
            deadline: document.getElementById('deadline').value
        };
        try {
            if (form.dataset.editId) {
                await apiCall(`/jobs/${form.dataset.editId}`, { method: 'PUT', body: job });
                showToast('Job updated successfully!');
            } else {
                const result = await apiCall('/jobs', { method: 'POST', body: job });
                showToast(result.message || 'Job posted successfully!');
            }
            setTimeout(() => window.location.href = '/my-jobs.html', 1500);
        } catch (err) {
            showToast(err.message, 'error');
        }
    });
}

// My Jobs
async function loadMyJobs() {
    await initPage('my-jobs');
    if (!requireAuth()) return;

    try {
        const jobs = await apiCall('/jobs/my-posted');
        const container = document.getElementById('myJobsContainer');
        if (jobs.length === 0) {
            container.innerHTML = `<div class="empty-state"><div class="icon">📋</div><h3>No jobs posted yet</h3><a href="/post-job.html" class="btn btn-primary" style="margin-top:16px">Post a Job</a></div>`;
            return;
        }
        container.innerHTML = jobs.map(job => `
            <div class="job-card" style="margin-bottom:16px">
                <div style="display:flex;justify-content:space-between;align-items:start">
                    <h3>${job.title}</h3>
                    ${statusBadge(job.status)}
                </div>
                <p class="description">${job.description}</p>
                <div class="job-meta">
                    <span>📁 ${job.category}</span>
                    <span class="job-budget">${formatCurrency(job.budget)}</span>
                    <span>📅 ${job.deadline}</span>
                </div>
                <div style="display:flex;gap:8px;margin-top:12px;flex-wrap:wrap">
                    ${job.status === 'OPEN' ? `
                        <a href="/post-job.html?edit=${job.id}" class="btn btn-sm btn-outline">Edit</a>
                        <button class="btn btn-sm btn-danger" onclick="cancelJob(${job.id})">Cancel</button>
                        <a href="/proposals.html?jobId=${job.id}" class="btn btn-sm btn-primary">View Proposals</a>
                    ` : ''}
                    ${job.status === 'SUBMITTED' ? `<a href="/submit-work.html?jobId=${job.id}" class="btn btn-sm btn-primary">Review Work</a>` : ''}
                    <a href="/job-details.html?id=${job.id}" class="btn btn-sm btn-outline">Details</a>
                </div>
            </div>
        `).join('');
    } catch (err) {
        showToast(err.message, 'error');
    }
}

async function cancelJob(id) {
    if (!confirm('Are you sure you want to cancel this job?')) return;
    try {
        await apiCall(`/jobs/${id}`, { method: 'DELETE' });
        showToast('Job cancelled');
        loadMyJobs();
    } catch (err) {
        showToast(err.message, 'error');
    }
}

// Proposals
async function loadProposals() {
    await initPage('my-jobs');
    if (!requireAuth()) return;

    const params = new URLSearchParams(window.location.search);
    const jobId = params.get('jobId');
    if (!jobId) { window.location.href = '/my-jobs.html'; return; }

    try {
        const job = await apiCall(`/jobs/${jobId}`);
        document.getElementById('proposalsHeader').innerHTML = `<h2>Proposals for: ${job.title}</h2>`;

        const proposals = await apiCall(`/jobs/${jobId}/proposals`);
        const container = document.getElementById('proposalsContainer');
        if (proposals.length === 0) {
            container.innerHTML = `<div class="empty-state"><div class="icon">📭</div><h3>No proposals yet</h3></div>`;
            return;
        }
        container.innerHTML = proposals.map(p => `
            <div class="proposal-card">
                <div class="proposal-header">
                    <div>
                        <h3>${p.freelancerName}</h3>
                        ${skillsHtml(p.freelancerSkills)}
                        <p>⭐ ${p.freelancerRating || 0} (${p.freelancerReviews || 0} reviews)</p>
                    </div>
                    ${statusBadge(p.status)}
                </div>
                <div class="detail-row">
                    <div class="detail-item"><label>Proposed Price</label><span>${formatCurrency(p.proposedPrice)}</span></div>
                    <div class="detail-item"><label>Delivery</label><span>${p.deliveryDays} days</span></div>
                </div>
                <p style="margin:12px 0;padding:12px;background:var(--bg);border-radius:8px">"${p.coverMessage}"</p>
                ${p.status === 'PENDING' ? `
                    <div class="proposal-actions">
                        <button class="btn btn-sm btn-success" onclick="hireFreelancer(${p.id})">Hire</button>
                        <button class="btn btn-sm btn-danger" onclick="rejectProposal(${p.id})">Reject</button>
                    </div>
                ` : ''}
            </div>
        `).join('');
    } catch (err) {
        showToast(err.message, 'error');
    }
}

async function hireFreelancer(id) {
    if (!confirm('Hire this freelancer?')) return;
    try {
        const result = await apiCall(`/proposals/${id}/accept`, { method: 'PUT' });
        showToast(result.message || 'Freelancer hired!');
        loadProposals();
    } catch (err) {
        showToast(err.message, 'error');
    }
}

async function rejectProposal(id) {
    try {
        await apiCall(`/proposals/${id}/reject`, { method: 'PUT' });
        showToast('Proposal rejected');
        loadProposals();
    } catch (err) {
        showToast(err.message, 'error');
    }
}

// Active Jobs
async function loadActiveJobs() {
    await initPage('active');
    if (!requireAuth()) return;

    try {
        const jobs = await apiCall('/jobs/active');
        const clientJobs = jobs.filter(j => j.clientId === currentUser.id);
        const freelanceJobs = jobs.filter(j => j.freelancerId === currentUser.id);

        document.getElementById('clientJobs').innerHTML = clientJobs.length
            ? clientJobs.map(j => activeJobCard(j, 'freelancer')).join('')
            : '<div class="empty-state"><p>No client jobs in progress</p></div>';

        document.getElementById('freelanceJobs').innerHTML = freelanceJobs.length
            ? freelanceJobs.map(j => activeJobCard(j, 'client')).join('')
            : '<div class="empty-state"><p>No freelance jobs in progress</p></div>';
    } catch (err) {
        showToast(err.message, 'error');
    }
}

function activeJobCard(job, otherRole) {
    const otherName = otherRole === 'client' ? job.clientName : job.freelancerName;
    return `
        <div class="job-card" style="margin-bottom:16px">
            <div style="display:flex;justify-content:space-between">
                <h3>${job.title}</h3>
                ${statusBadge(job.status)}
            </div>
            <div class="job-meta">
                <span>👤 ${otherRole === 'client' ? 'Client' : 'Freelancer'}: ${otherName || 'N/A'}</span>
                <span class="job-budget">${formatCurrency(job.budget)}</span>
                <span>📅 ${job.deadline}</span>
            </div>
            <div style="margin-top:12px">
                ${job.status === 'IN_PROGRESS' && job.freelancerId === currentUser?.id
                    ? `<a href="/submit-work.html?jobId=${job.id}" class="btn btn-sm btn-primary">Submit Work</a>` : ''}
                ${job.status === 'SUBMITTED' && job.clientId === currentUser?.id
                    ? `<a href="/submit-work.html?jobId=${job.id}" class="btn btn-sm btn-primary">Review Work</a>` : ''}
                <a href="/job-details.html?id=${job.id}" class="btn btn-sm btn-outline">Details</a>
            </div>
        </div>`;
}

// Completed Jobs
async function loadCompletedJobs() {
    await initPage('active');
    if (!requireAuth()) return;

    try {
        const jobs = await apiCall('/jobs/completed');
        const container = document.getElementById('completedContainer');
        if (jobs.length === 0) {
            container.innerHTML = `<div class="empty-state"><div class="icon">✅</div><h3>No completed jobs yet</h3></div>`;
            return;
        }

        const jobsHtml = await Promise.all(jobs.map(async (job) => {
            let paymentHtml = '';
            try {
                const payment = await apiCall(`/jobs/${job.id}/payment`);
                if (payment.status === 'COMPLETED') {
                    paymentHtml = `<span class="badge badge-accepted">💳 Paid ${formatCurrency(payment.amount)}</span>`;
                }
            } catch {}

            return `
            <div class="job-card" style="margin-bottom:16px">
                <h3>${job.title}</h3>
                <div class="job-meta">
                    <span>👤 Client: ${job.clientName || 'N/A'}</span>
                    <span>👤 Freelancer: ${job.freelancerName || 'N/A'}</span>
                    <span class="job-budget">${formatCurrency(job.budget)}</span>
                    <span>✅ ${formatDate(job.completedAt)}</span>
                    ${paymentHtml}
                </div>
                ${job.clientId === currentUser.id ? `
                    <button class="btn btn-sm btn-primary" style="margin-top:12px" onclick="showReviewForm(${job.id})">⭐ Leave Review</button>
                ` : ''}
            </div>`;
        }));

        container.innerHTML = jobsHtml.join('');

        const params = new URLSearchParams(window.location.search);
        const reviewJobId = params.get('reviewJob');
        if (reviewJobId) {
            showReviewForm(reviewJobId);
            showToast('Work accepted! Please leave a review for the freelancer.', 'info');
        }
    } catch (err) {
        showToast(err.message, 'error');
    }
}

function showReviewForm(jobId) {
    document.getElementById('reviewModal').style.display = 'flex';
    document.getElementById('reviewForm').dataset.jobId = jobId;
}

async function submitReview(e) {
    e.preventDefault();
    const jobId = e.target.dataset.jobId;
    const review = {
        rating: parseInt(document.getElementById('rating').value),
        comment: document.getElementById('comment').value
    };
    try {
        await apiCall(`/jobs/${jobId}/reviews`, { method: 'POST', body: review });
        showToast('Review submitted!');
        document.getElementById('reviewModal').style.display = 'none';
        loadCompletedJobs();
    } catch (err) {
        showToast(err.message, 'error');
    }
}

// Submit Work
let currentJobData = null;

async function loadSubmitWork() {
    await initPage('active');
    if (!requireAuth()) return;

    const params = new URLSearchParams(window.location.search);
    const jobId = params.get('jobId');
    if (!jobId) { window.location.href = '/active-jobs.html'; return; }

    try {
        const job = await apiCall(`/jobs/${jobId}`);
        currentJobData = job;
        document.getElementById('workJobTitle').textContent = job.title;

        const isClient = job.clientId === currentUser.id;
        const isFreelancer = job.freelancerId === currentUser.id;

        if (isFreelancer && (job.status === 'IN_PROGRESS' || job.status === 'SUBMITTED')) {
            document.getElementById('submitForm').style.display = 'block';
            try {
                const sub = await apiCall(`/jobs/${jobId}/submission`);
                document.getElementById('workLink').value = sub.workLink || '';
                document.getElementById('workMessage').value = sub.message || '';

                if (sub.changeRequestMessage) {
                    document.getElementById('changeFeedback').style.display = 'block';
                    document.getElementById('changeFeedbackText').textContent = sub.changeRequestMessage;
                }
            } catch {}
        }

        if (isClient && job.status === 'SUBMITTED') {
            document.getElementById('clientReview').style.display = 'block';
            try {
                const sub = await apiCall(`/jobs/${jobId}/submission`);
                document.getElementById('submissionDetails').innerHTML = `
                    <div class="card">
                        <p><strong>Work Link:</strong> <a href="${sub.workLink}" target="_blank">${sub.workLink}</a></p>
                        <p style="margin-top:12px"><strong>Freelancer Message:</strong> ${sub.message}</p>
                        <p style="margin-top:8px;color:var(--text-light)">Submitted: ${formatDate(sub.submittedAt)}</p>
                    </div>`;
                document.getElementById('paymentAmount').textContent = formatCurrency(job.budget);
            } catch {}
        }
    } catch (err) {
        showToast(err.message, 'error');
    }

    document.getElementById('submitForm')?.addEventListener('submit', async (e) => {
        e.preventDefault();
        const submission = {
            workLink: document.getElementById('workLink').value,
            message: document.getElementById('workMessage').value
        };
        try {
            const result = await apiCall(`/jobs/${jobId}/submission`, { method: 'POST', body: submission });
            showToast(result.message || 'Work submitted! Waiting for client review.');
            setTimeout(() => window.location.href = '/active-jobs.html', 1500);
        } catch (err) {
            showToast(err.message, 'error');
        }
    });
}

function showPaymentModal() {
    if (!currentJobData) return;
    document.getElementById('modalPaymentAmount').textContent = formatCurrency(currentJobData.budget);
    document.getElementById('modalJobTitle').textContent = currentJobData.title;
    document.getElementById('paymentModal').style.display = 'flex';
}

function closePaymentModal() {
    document.getElementById('paymentModal').style.display = 'none';
}

function showChangeRequestModal() {
    document.getElementById('changeRequestModal').style.display = 'flex';
}

function closeChangeRequestModal() {
    document.getElementById('changeRequestModal').style.display = 'none';
}

async function confirmPayment() {
    const params = new URLSearchParams(window.location.search);
    const jobId = params.get('jobId');
    try {
        const result = await apiCall(`/jobs/${jobId}/accept-work`, { method: 'PUT' });
        closePaymentModal();
        showToast(result.message || 'Payment completed & work accepted!');
        setTimeout(() => window.location.href = `/completed-jobs.html?reviewJob=${jobId}`, 2000);
    } catch (err) {
        showToast(err.message, 'error');
    }
}

async function submitChangeRequest(e) {
    e.preventDefault();
    const params = new URLSearchParams(window.location.search);
    const jobId = params.get('jobId');
    const feedback = document.getElementById('changeFeedbackInput').value.trim();
    if (!feedback) {
        showToast('Please describe what changes are needed', 'error');
        return;
    }
    try {
        const result = await apiCall(`/jobs/${jobId}/request-changes`, {
            method: 'PUT',
            body: { feedback }
        });
        closeChangeRequestModal();
        showToast(result.message || 'Feedback sent to freelancer!');
        setTimeout(() => window.location.href = '/active-jobs.html', 2000);
    } catch (err) {
        showToast(err.message, 'error');
    }
}

async function acceptWork() {
    showPaymentModal();
}

async function requestChanges() {
    showChangeRequestModal();
}
